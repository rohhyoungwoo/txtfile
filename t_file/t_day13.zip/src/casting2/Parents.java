package casting2;
//6번 : 자식객체의 타입 여러개인지 확인-부모클래스
public class Parents {

}
