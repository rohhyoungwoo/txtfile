package review3;

public class SavingsAccount extends Account{
//	SavingsAccount 클래스
//	메소드 
//	   withdraw()를 오버라이딩하여 출금 시 잔액이 부족하면 "출금 실패!" 출력
	
	//생성자
	public SavingsAccount(double balance) {
		super(balance);
	}
}
