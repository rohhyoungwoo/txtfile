package task;

public class Animal {
//	Animal 클래스
//	부모클래스
//	필드: 없음
//	메소드: cry() (소리를 출력)
	
	//메소드 
	void cry(){
		System.out.println("동물소리");
	}
}
