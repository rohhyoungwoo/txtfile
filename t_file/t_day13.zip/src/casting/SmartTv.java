package casting;
//4번 : casting 자식 클래스
public class SmartTv extends Tv{
	//메소드
	void netflix() {
		System.out.println("넷플릭스 실행");
	}
}
