package review;

import java.util.Random;

public class Test {
	public static void main(String[] args) {
		
		Random random = new Random();
		System.out.println(random.nextInt(10) + 1);
		
				
	}
}
