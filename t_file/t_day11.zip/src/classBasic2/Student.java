package classBasic2;
//3번 : 클래스 특징1(사용자 정의 타입이다)
public class Student {
	//필드
	String name; //학생 이름
	int	age;	//학생 나이
	double gpa;	//학점
}
